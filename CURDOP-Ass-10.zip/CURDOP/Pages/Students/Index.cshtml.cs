using curdop.Pages.Clients;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace curdop.Pages.Students
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;
        public List<ClientInfo> listClients = new List<ClientInfo>();

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            try
            {
                // Fetch the connection string from appsettings.json
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM students";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ClientInfo clientInfo = new ClientInfo();
                                clientInfo.student_id = reader.GetInt32(0).ToString();  // Correct index for student_id
                                clientInfo.first_name = reader.GetString(1);  // Correct index for first_name
                                clientInfo.last_name = reader.GetString(2);  // Correct index for last_name
                                clientInfo.age = reader.GetInt32(3).ToString();  // Correct index for age
                                clientInfo.major = reader.GetString(4);  // Correct index for major

                                listClients.Add(clientInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }

    public class ClientInfo
    {
        public string student_id;
        public string first_name;
        public string last_name;
        public string age;
        public string major;
    }
}
